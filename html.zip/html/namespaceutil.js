var namespaceutil =
[
    [ "MyWarning2", "classutil_1_1_my_warning2.html", null ],
    [ "generate_warning", "namespaceutil.html#a50143dfb7694c2e078298efe24df1f81", null ]
];