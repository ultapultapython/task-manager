var namespacexdist_1_1remote =
[
    [ "Marker", "classxdist_1_1remote_1_1_marker.html", null ],
    [ "Producer", "classxdist_1_1remote_1_1_producer.html", "classxdist_1_1remote_1_1_producer" ],
    [ "TestQueue", "classxdist_1_1remote_1_1_test_queue.html", "classxdist_1_1remote_1_1_test_queue" ],
    [ "WorkerInfo", "classxdist_1_1remote_1_1_worker_info.html", null ],
    [ "WorkerInteractor", "classxdist_1_1remote_1_1_worker_interactor.html", "classxdist_1_1remote_1_1_worker_interactor" ],
    [ "getinfodict", "namespacexdist_1_1remote.html#a9f10c9e242788622bdec2b02ed2b20f8", null ],
    [ "serialize_warning_message", "namespacexdist_1_1remote.html#a3aab3a61678db19d656c565d289643ec", null ],
    [ "setproctitle", "namespacexdist_1_1remote.html#a29e9224012e153b5cc0c6dcdb5b3545a", null ],
    [ "setup_config", "namespacexdist_1_1remote.html#a2654fddd003cc025707e04e0ba4f0216", null ],
    [ "worker_title", "namespacexdist_1_1remote.html#aae43c821d04477902a2649db27251c5e", null ],
    [ "args", "namespacexdist_1_1remote.html#a8204e0b3393e3e4f523198b4c0b852ee", null ],
    [ "change_sys_path", "namespacexdist_1_1remote.html#a444ffb9e38f18610016eb4db8a45e6af", null ],
    [ "channel", "namespacexdist_1_1remote.html#ad845bdfec63f2a98219c578de8df1535", null ],
    [ "config", "namespacexdist_1_1remote.html#ada51f9290119b578353cf4a6f95db917", null ],
    [ "importpath", "namespacexdist_1_1remote.html#a9818476ef60139e6c5603e946cb499f7", null ],
    [ "interactor", "namespacexdist_1_1remote.html#af994116f680289f9b4822759b642cb16", null ],
    [ "option_dict", "namespacexdist_1_1remote.html#a10498acecf805d2a791ba23e737480ed", null ],
    [ "path", "namespacexdist_1_1remote.html#a994bfca60e093f9e1bf2be1918e0f12e", null ],
    [ "prog", "namespacexdist_1_1remote.html#aecafa3ff92c29a54186066bbfdd8af6d", null ],
    [ "workerinput", "namespacexdist_1_1remote.html#aa1af5b314f17fb997ae73e03eab50f6e", null ],
    [ "workeroutput", "namespacexdist_1_1remote.html#a5955f9205efae81c40e18d37074c633d", null ]
];