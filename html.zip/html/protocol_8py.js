var protocol_8py =
[
    [ "xdist.scheduler.protocol.Scheduling", "classxdist_1_1scheduler_1_1protocol_1_1_scheduling.html", "classxdist_1_1scheduler_1_1protocol_1_1_scheduling" ]
];