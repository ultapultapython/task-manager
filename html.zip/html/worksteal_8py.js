var worksteal_8py =
[
    [ "xdist.scheduler.worksteal.NodePending", "classxdist_1_1scheduler_1_1worksteal_1_1_node_pending.html", null ],
    [ "xdist.scheduler.worksteal.WorkStealingScheduling", "classxdist_1_1scheduler_1_1worksteal_1_1_work_stealing_scheduling.html", "classxdist_1_1scheduler_1_1worksteal_1_1_work_stealing_scheduling" ],
    [ "xdist.scheduler.worksteal.MIN_PENDING", "namespacexdist_1_1scheduler_1_1worksteal.html#a56bbbbfa9a9c70dbc67d0b0cb7485855", null ]
];