var classtest__looponfail_1_1_test_remote_control =
[
    [ "test_failure_change", "classtest__looponfail_1_1_test_remote_control.html#a490ab3fcb5394b0ef52469cd224f0eea", null ],
    [ "test_failure_subdir_no_init", "classtest__looponfail_1_1_test_remote_control.html#ae4cdc9f69066e00430af5be72f527eb2", null ],
    [ "test_failures_somewhere", "classtest__looponfail_1_1_test_remote_control.html#a6c11fdbbd7703f11631fb74b610860e9", null ],
    [ "test_ignore_sys_path_hook_entry", "classtest__looponfail_1_1_test_remote_control.html#aa8ae1c2b6f291c3bfefdf07d1dd49a1e", null ],
    [ "test_nofailures", "classtest__looponfail_1_1_test_remote_control.html#a95931641819712e2cb68d7fe5cb8475c", null ]
];