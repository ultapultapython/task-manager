var namespacetest__newhooks =
[
    [ "TestCrashItem", "classtest__newhooks_1_1_test_crash_item.html", "classtest__newhooks_1_1_test_crash_item" ],
    [ "TestHooks", "classtest__newhooks_1_1_test_hooks.html", "classtest__newhooks_1_1_test_hooks" ]
];