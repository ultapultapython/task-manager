var newhooks_8py =
[
    [ "xdist.newhooks.pytest_configure_node", "namespacexdist_1_1newhooks.html#a493f7fa921079d624bdd27b0535acbb3", null ],
    [ "xdist.newhooks.pytest_handlecrashitem", "namespacexdist_1_1newhooks.html#a7e9e029b1ef61339ba0ec34eb4541548", null ],
    [ "xdist.newhooks.pytest_testnodedown", "namespacexdist_1_1newhooks.html#aef52f9444f1847c9ad47cafdaf798cd9", null ],
    [ "xdist.newhooks.pytest_testnodeready", "namespacexdist_1_1newhooks.html#ab601ea2e660aeef9ad877646166d7e24", null ],
    [ "xdist.newhooks.pytest_xdist_auto_num_workers", "namespacexdist_1_1newhooks.html#acabdf27c4dc600f260a34e37ac13a544", null ],
    [ "xdist.newhooks.pytest_xdist_getremotemodule", "namespacexdist_1_1newhooks.html#afb0d4b440ceaf03da276e00330bc9f46", null ],
    [ "xdist.newhooks.pytest_xdist_make_scheduler", "namespacexdist_1_1newhooks.html#a7648e2ae4bf9871a6b24462182009a80", null ],
    [ "xdist.newhooks.pytest_xdist_newgateway", "namespacexdist_1_1newhooks.html#ae7c09cc5484abd6855c62ef639ba1b83", null ],
    [ "xdist.newhooks.pytest_xdist_node_collection_finished", "namespacexdist_1_1newhooks.html#a68a926f0d3b7b59ede4b3c8105dc8308", null ],
    [ "xdist.newhooks.pytest_xdist_rsyncfinish", "namespacexdist_1_1newhooks.html#a99409537b6f17cb21d2d7f8f54c58d4b", null ],
    [ "xdist.newhooks.pytest_xdist_rsyncstart", "namespacexdist_1_1newhooks.html#a008ebfc667cf96b532396c4a7a860dac", null ],
    [ "xdist.newhooks.pytest_xdist_setupnodes", "namespacexdist_1_1newhooks.html#adcfbaea9a37e104fe9ea5b5292bd0736", null ]
];