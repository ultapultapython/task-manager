var hierarchy =
[
    [ "BaseOfMockGateway", null, [
      [ "test_dsession.MockGateway", "classtest__dsession_1_1_mock_gateway.html", null ]
    ] ],
    [ "BaseOfMockNode", null, [
      [ "test_dsession.MockNode", "classtest__dsession_1_1_mock_node.html", null ]
    ] ],
    [ "xdist.dsession.DSession", "classxdist_1_1dsession_1_1_d_session.html", null ],
    [ "xdist.scheduler.each.EachScheduling", "classxdist_1_1scheduler_1_1each_1_1_each_scheduling.html", null ],
    [ "Enum", null, [
      [ "xdist.dsession.WorkerStatus", "classxdist_1_1dsession_1_1_worker_status.html", null ]
    ] ],
    [ "enum.Enum", null, [
      [ "xdist.remote.Marker", "classxdist_1_1remote_1_1_marker.html", null ],
      [ "xdist.workermanage.Marker", "classxdist_1_1workermanage_1_1_marker.html", null ]
    ] ],
    [ "test_remote.EventCall", "classtest__remote_1_1_event_call.html", null ],
    [ "KeyboardInterrupt", null, [
      [ "xdist.dsession.Interrupted", "classxdist_1_1dsession_1_1_interrupted.html", null ]
    ] ],
    [ "xdist.scheduler.load.LoadScheduling", "classxdist_1_1scheduler_1_1load_1_1_load_scheduling.html", null ],
    [ "xdist.scheduler.loadscope.LoadScopeScheduling", "classxdist_1_1scheduler_1_1loadscope_1_1_load_scope_scheduling.html", [
      [ "xdist.scheduler.loadfile.LoadFileScheduling", "classxdist_1_1scheduler_1_1loadfile_1_1_load_file_scheduling.html", null ],
      [ "xdist.scheduler.loadgroup.LoadGroupScheduling", "classxdist_1_1scheduler_1_1loadgroup_1_1_load_group_scheduling.html", null ]
    ] ],
    [ "NamedTuple", null, [
      [ "xdist.scheduler.worksteal.NodePending", "classxdist_1_1scheduler_1_1worksteal_1_1_node_pending.html", null ]
    ] ],
    [ "xdist.workermanage.NodeManager", "classxdist_1_1workermanage_1_1_node_manager.html", null ],
    [ "xdist.remote.Producer", "classxdist_1_1remote_1_1_producer.html", null ],
    [ "Protocol", null, [
      [ "xdist.scheduler.protocol.Scheduling", "classxdist_1_1scheduler_1_1protocol_1_1_scheduling.html", null ]
    ] ],
    [ "xdist.looponfail.RemoteControl", "classxdist_1_1looponfail_1_1_remote_control.html", null ],
    [ "xdist.workermanage.WorkerController.RemoteHook", "classxdist_1_1workermanage_1_1_worker_controller_1_1_remote_hook.html", null ],
    [ "execnet.RSync", null, [
      [ "xdist.workermanage.HostRSync", "classxdist_1_1workermanage_1_1_host_r_sync.html", null ]
    ] ],
    [ "xdist.looponfail.StatRecorder", "classxdist_1_1looponfail_1_1_stat_recorder.html", null ],
    [ "xdist.dsession.TerminalDistReporter", "classxdist_1_1dsession_1_1_terminal_dist_reporter.html", null ],
    [ "acceptance_test.TestAPI", "classacceptance__test_1_1_test_a_p_i.html", null ],
    [ "TestCase", null, [
      [ "test_delta.Delta1", "classtest__delta_1_1_delta1.html", null ],
      [ "test_delta.Delta2", "classtest__delta_1_1_delta2.html", null ]
    ] ],
    [ "test_newhooks.TestCrashItem", "classtest__newhooks_1_1_test_crash_item.html", null ],
    [ "acceptance_test.TestDistEach", "classacceptance__test_1_1_test_dist_each.html", null ],
    [ "test_plugin.TestDistOptions", "classtest__plugin_1_1_test_dist_options.html", null ],
    [ "test_dsession.TestDistReporter", "classtest__dsession_1_1_test_dist_reporter.html", null ],
    [ "acceptance_test.TestDistribution", "classacceptance__test_1_1_test_distribution.html", null ],
    [ "test_dsession.TestEachScheduling", "classtest__dsession_1_1_test_each_scheduling.html", null ],
    [ "acceptance_test.TestFileScope", "classacceptance__test_1_1_test_file_scope.html", null ],
    [ "test_looponfail.TestFunctional", "classtest__looponfail_1_1_test_functional.html", null ],
    [ "acceptance_test.TestGroupScope", "classacceptance__test_1_1_test_group_scope.html", null ],
    [ "test_newhooks.TestHooks", "classtest__newhooks_1_1_test_hooks.html", null ],
    [ "test_workermanage.TestHRSync", "classtest__workermanage_1_1_test_h_r_sync.html", null ],
    [ "test_dsession.TestLoadScheduling", "classtest__dsession_1_1_test_load_scheduling.html", null ],
    [ "acceptance_test.TestLoadScope", "classacceptance__test_1_1_test_load_scope.html", null ],
    [ "acceptance_test.TestLocking", "classacceptance__test_1_1_test_locking.html", null ],
    [ "test_looponfail.TestLooponFailing", "classtest__looponfail_1_1_test_loopon_failing.html", null ],
    [ "acceptance_test.TestNodeFailure", "classacceptance__test_1_1_test_node_failure.html", null ],
    [ "test_workermanage.TestNodeManager", "classtest__workermanage_1_1_test_node_manager.html", null ],
    [ "test_workermanage.TestNodeManagerPopen", "classtest__workermanage_1_1_test_node_manager_popen.html", null ],
    [ "xdist.remote.TestQueue", "classxdist_1_1remote_1_1_test_queue.html", null ],
    [ "test_looponfail.TestRemoteControl", "classtest__looponfail_1_1_test_remote_control.html", null ],
    [ "test_looponfail.TestStatRecorder", "classtest__looponfail_1_1_test_stat_recorder.html", null ],
    [ "acceptance_test.TestTerminalReporting", "classacceptance__test_1_1_test_terminal_reporting.html", null ],
    [ "acceptance_test.TestWarnings", "classacceptance__test_1_1_test_warnings.html", null ],
    [ "test_remote.TestWorkerInteractor", "classtest__remote_1_1_test_worker_interactor.html", null ],
    [ "test_dsession.TestWorkStealingScheduling", "classtest__dsession_1_1_test_work_stealing_scheduling.html", null ],
    [ "TypedDict", null, [
      [ "xdist.remote.WorkerInfo", "classxdist_1_1remote_1_1_worker_info.html", null ]
    ] ],
    [ "UserWarning", null, [
      [ "test_workermanage.MyWarning", "classtest__workermanage_1_1_my_warning.html", null ],
      [ "test_workermanage.MyWarningUnknown", "classtest__workermanage_1_1_my_warning_unknown.html", null ],
      [ "util.MyWarning2", "classutil_1_1_my_warning2.html", null ]
    ] ],
    [ "xdist.workermanage.WorkerController", "classxdist_1_1workermanage_1_1_worker_controller.html", null ],
    [ "xdist.looponfail.WorkerFailSession", "classxdist_1_1looponfail_1_1_worker_fail_session.html", null ],
    [ "xdist.remote.WorkerInteractor", "classxdist_1_1remote_1_1_worker_interactor.html", null ],
    [ "test_remote.WorkerSetup", "classtest__remote_1_1_worker_setup.html", null ],
    [ "xdist.scheduler.worksteal.WorkStealingScheduling", "classxdist_1_1scheduler_1_1worksteal_1_1_work_stealing_scheduling.html", null ]
];