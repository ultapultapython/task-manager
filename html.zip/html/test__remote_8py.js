var test__remote_8py =
[
    [ "test_remote.EventCall", "classtest__remote_1_1_event_call.html", "classtest__remote_1_1_event_call" ],
    [ "test_remote.WorkerSetup", "classtest__remote_1_1_worker_setup.html", "classtest__remote_1_1_worker_setup" ],
    [ "test_remote.TestWorkerInteractor", "classtest__remote_1_1_test_worker_interactor.html", "classtest__remote_1_1_test_worker_interactor" ],
    [ "test_remote.check_marshallable", "namespacetest__remote.html#a2346bd693e3e0a67e82626a8a5603178", null ],
    [ "test_remote.test_remote_env_vars", "namespacetest__remote.html#a6228e3538a17685b62ca25dce167fb27", null ],
    [ "test_remote.test_remote_inner_argv", "namespacetest__remote.html#addc8bcd689ddae05cf034786f8e1638a", null ],
    [ "test_remote.test_remote_mainargv", "namespacetest__remote.html#a963e6fe254d972d962d4d1634d92c763", null ],
    [ "test_remote.test_remote_sys_path", "namespacetest__remote.html#aafac11427022445a5539bc326d478c3e", null ],
    [ "test_remote.test_remote_usage_prog", "namespacetest__remote.html#a283e4821ce823423faf636f5ea83b129", null ],
    [ "test_remote.worker", "namespacetest__remote.html#ab9a170cfb04d62784383ca2c34731c5b", null ],
    [ "test_remote.WAIT_TIMEOUT", "namespacetest__remote.html#a9d762cab65bf94516b3aac447a0b27ac", null ]
];