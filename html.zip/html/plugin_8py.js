var plugin_8py =
[
    [ "xdist.plugin._is_distribution_mode", "namespacexdist_1_1plugin.html#aa63f64a7d08a5ceb1ce0bf32cbfa7114", null ],
    [ "xdist.plugin.get_xdist_worker_id", "namespacexdist_1_1plugin.html#a76fce977190991e6e78f226a65b2e93b", null ],
    [ "xdist.plugin.is_xdist_controller", "namespacexdist_1_1plugin.html#acd2fde89c194d45f3c61ad72462961ea", null ],
    [ "xdist.plugin.is_xdist_worker", "namespacexdist_1_1plugin.html#a6c862597e099b16a4c3c2ba08fa5dd8a", null ],
    [ "xdist.plugin.parse_numprocesses", "namespacexdist_1_1plugin.html#a2ded1e52b021d5a72a3cd3ae55579484", null ],
    [ "xdist.plugin.pytest_addhooks", "namespacexdist_1_1plugin.html#a08c96e1d9c30984b16b59f6c03d90572", null ],
    [ "xdist.plugin.pytest_addoption", "namespacexdist_1_1plugin.html#a6d61a33a39e7847d5186a37fd99a9520", null ],
    [ "xdist.plugin.pytest_cmdline_main", "namespacexdist_1_1plugin.html#ae60bccf8eddb278b917ef53a24ef498d", null ],
    [ "xdist.plugin.pytest_configure", "namespacexdist_1_1plugin.html#aab7048583e1b2f34fd78c580854e7959", null ],
    [ "xdist.plugin.pytest_xdist_auto_num_workers", "namespacexdist_1_1plugin.html#aa132867daf456c612a49a0b9f9916afe", null ],
    [ "xdist.plugin.testrun_uid", "namespacexdist_1_1plugin.html#a8bf39b3db4d05f2fba7b2c9ac25aac60", null ],
    [ "xdist.plugin.worker_id", "namespacexdist_1_1plugin.html#a03fc2820c83066cd766de4bba61da681", null ],
    [ "xdist.plugin._sys_path", "namespacexdist_1_1plugin.html#a14ffeda533732441e0c6585789a2c131", null ],
    [ "xdist.plugin.is_xdist_master", "namespacexdist_1_1plugin.html#a6a437d82c4ab66aa99d9fe1218ef4251", null ]
];