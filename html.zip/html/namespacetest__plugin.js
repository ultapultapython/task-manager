var namespacetest__plugin =
[
    [ "TestDistOptions", "classtest__plugin_1_1_test_dist_options.html", "classtest__plugin_1_1_test_dist_options" ],
    [ "monkeypatch_3_cpus", "namespacetest__plugin.html#a4c44700854d496d934b39d98ff3f3cca", null ],
    [ "test_auto_detect_cpus", "namespacetest__plugin.html#aad91bc40cef00ec7c515d5bb3fa422b7", null ],
    [ "test_auto_detect_cpus_os", "namespacetest__plugin.html#a716c480bfaef13f1d08095e4452aafd4", null ],
    [ "test_auto_detect_cpus_psutil", "namespacetest__plugin.html#acae3f26d017f947eefe4a9ee6b2f8d91", null ],
    [ "test_auto_num_workers_hook_overrides_envvar", "namespacetest__plugin.html#a041ddcdc33d84706b1b8177f0bde20c5", null ],
    [ "test_dist_incompatibility_messages", "namespacetest__plugin.html#ac98635bd74b20b46d48e7e3cdd3fe4b9", null ],
    [ "test_dist_options", "namespacetest__plugin.html#a00f32012f82546d93e1883274e8fa0ca", null ],
    [ "test_dsession_with_collect_only", "namespacetest__plugin.html#ad66421b1d79bb52fe4d22096eac0c26e", null ],
    [ "test_envvar_auto_num_workers", "namespacetest__plugin.html#a5ef573f6e9061312bac87df195c31683", null ],
    [ "test_envvar_auto_num_workers_warn", "namespacetest__plugin.html#a7ee871ccf135538c6c42d8a5b07d0260", null ],
    [ "test_hook_auto_num_workers", "namespacetest__plugin.html#a8def2d203bf4d8b4880b89c4803bd909", null ],
    [ "test_hook_auto_num_workers_arg", "namespacetest__plugin.html#aaba0e056cf7692a079f6ab099ca92cbf", null ],
    [ "test_hook_auto_num_workers_none", "namespacetest__plugin.html#a7e0412b9a96fb1698d3d4978e55ef23d", null ],
    [ "test_testrunuid_generated", "namespacetest__plugin.html#a9c41bca730aa443c569b6e6e05efec88", null ],
    [ "test_testrunuid_provided", "namespacetest__plugin.html#a336d44022f1a15da84a07bbace93056c", null ]
];