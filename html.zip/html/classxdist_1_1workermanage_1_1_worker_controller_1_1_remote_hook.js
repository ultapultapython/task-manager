var classxdist_1_1workermanage_1_1_worker_controller_1_1_remote_hook =
[
    [ "pytest_xdist_getremotemodule", "classxdist_1_1workermanage_1_1_worker_controller_1_1_remote_hook.html#a81948daaa5b790c81e034484771a3040", null ]
];