var conf_8py =
[
    [ "conf.author", "namespaceconf.html#a0b68e66074bc74dbb7460951f810b4c8", null ],
    [ "conf.copyright", "namespaceconf.html#aa11e0a8e9c47ccc775796bd64c295d2c", null ],
    [ "conf.exclude_patterns", "namespaceconf.html#a7ad48fb6f3e9b129c02346ea0d3527c1", null ],
    [ "conf.extensions", "namespaceconf.html#ae475e080536acb271a0a0efe56c3ba42", null ],
    [ "conf.html_theme", "namespaceconf.html#a012ba9863b958ed7baa933116f2a05b6", null ],
    [ "conf.master_doc", "namespaceconf.html#aa95c63cf0a3d87fed36d450840c6fd48", null ],
    [ "conf.project", "namespaceconf.html#a2803387c30920e3e74f46eb541db430d", null ],
    [ "conf.templates_path", "namespaceconf.html#ae850ae634911b713e036b43894fdd525", null ]
];