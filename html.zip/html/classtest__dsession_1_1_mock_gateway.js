var classtest__dsession_1_1_mock_gateway =
[
    [ "__init__", "classtest__dsession_1_1_mock_gateway.html#a240ff827c6e89c0ae1c437c7eb955e9f", null ],
    [ "_count", "classtest__dsession_1_1_mock_gateway.html#a290609896009b8d49b12495d441944c4", null ],
    [ "id", "classtest__dsession_1_1_mock_gateway.html#a6bd587e52f96d8478b382b216211af81", null ]
];