var namespacexdist_1_1dsession =
[
    [ "DSession", "classxdist_1_1dsession_1_1_d_session.html", "classxdist_1_1dsession_1_1_d_session" ],
    [ "Interrupted", "classxdist_1_1dsession_1_1_interrupted.html", null ],
    [ "TerminalDistReporter", "classxdist_1_1dsession_1_1_terminal_dist_reporter.html", "classxdist_1_1dsession_1_1_terminal_dist_reporter" ],
    [ "WorkerStatus", "classxdist_1_1dsession_1_1_worker_status.html", null ],
    [ "get_default_max_worker_restart", "namespacexdist_1_1dsession.html#ab410461f3554f87860821e1a454183cc", null ],
    [ "get_workers_status_line", "namespacexdist_1_1dsession.html#a54cca940f31d6fe71088fe6ab6aed8b2", null ]
];