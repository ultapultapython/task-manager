var namespacexdist =
[
    [ "_path", "namespacexdist_1_1__path.html", [
      [ "visit_path", "namespacexdist_1_1__path.html#a482e619c2d0dc586c8249e7d51a69836", null ]
    ] ],
    [ "dsession", "namespacexdist_1_1dsession.html", "namespacexdist_1_1dsession" ],
    [ "looponfail", "namespacexdist_1_1looponfail.html", "namespacexdist_1_1looponfail" ],
    [ "newhooks", "namespacexdist_1_1newhooks.html", [
      [ "pytest_configure_node", "namespacexdist_1_1newhooks.html#a493f7fa921079d624bdd27b0535acbb3", null ],
      [ "pytest_handlecrashitem", "namespacexdist_1_1newhooks.html#a7e9e029b1ef61339ba0ec34eb4541548", null ],
      [ "pytest_testnodedown", "namespacexdist_1_1newhooks.html#aef52f9444f1847c9ad47cafdaf798cd9", null ],
      [ "pytest_testnodeready", "namespacexdist_1_1newhooks.html#ab601ea2e660aeef9ad877646166d7e24", null ],
      [ "pytest_xdist_auto_num_workers", "namespacexdist_1_1newhooks.html#acabdf27c4dc600f260a34e37ac13a544", null ],
      [ "pytest_xdist_getremotemodule", "namespacexdist_1_1newhooks.html#afb0d4b440ceaf03da276e00330bc9f46", null ],
      [ "pytest_xdist_make_scheduler", "namespacexdist_1_1newhooks.html#a7648e2ae4bf9871a6b24462182009a80", null ],
      [ "pytest_xdist_newgateway", "namespacexdist_1_1newhooks.html#ae7c09cc5484abd6855c62ef639ba1b83", null ],
      [ "pytest_xdist_node_collection_finished", "namespacexdist_1_1newhooks.html#a68a926f0d3b7b59ede4b3c8105dc8308", null ],
      [ "pytest_xdist_rsyncfinish", "namespacexdist_1_1newhooks.html#a99409537b6f17cb21d2d7f8f54c58d4b", null ],
      [ "pytest_xdist_rsyncstart", "namespacexdist_1_1newhooks.html#a008ebfc667cf96b532396c4a7a860dac", null ],
      [ "pytest_xdist_setupnodes", "namespacexdist_1_1newhooks.html#adcfbaea9a37e104fe9ea5b5292bd0736", null ]
    ] ],
    [ "plugin", "namespacexdist_1_1plugin.html", [
      [ "_is_distribution_mode", "namespacexdist_1_1plugin.html#aa63f64a7d08a5ceb1ce0bf32cbfa7114", null ],
      [ "get_xdist_worker_id", "namespacexdist_1_1plugin.html#a76fce977190991e6e78f226a65b2e93b", null ],
      [ "is_xdist_controller", "namespacexdist_1_1plugin.html#acd2fde89c194d45f3c61ad72462961ea", null ],
      [ "is_xdist_worker", "namespacexdist_1_1plugin.html#a6c862597e099b16a4c3c2ba08fa5dd8a", null ],
      [ "parse_numprocesses", "namespacexdist_1_1plugin.html#a2ded1e52b021d5a72a3cd3ae55579484", null ],
      [ "pytest_addhooks", "namespacexdist_1_1plugin.html#a08c96e1d9c30984b16b59f6c03d90572", null ],
      [ "pytest_addoption", "namespacexdist_1_1plugin.html#a6d61a33a39e7847d5186a37fd99a9520", null ],
      [ "pytest_cmdline_main", "namespacexdist_1_1plugin.html#ae60bccf8eddb278b917ef53a24ef498d", null ],
      [ "pytest_configure", "namespacexdist_1_1plugin.html#aab7048583e1b2f34fd78c580854e7959", null ],
      [ "pytest_xdist_auto_num_workers", "namespacexdist_1_1plugin.html#aa132867daf456c612a49a0b9f9916afe", null ],
      [ "testrun_uid", "namespacexdist_1_1plugin.html#a8bf39b3db4d05f2fba7b2c9ac25aac60", null ],
      [ "worker_id", "namespacexdist_1_1plugin.html#a03fc2820c83066cd766de4bba61da681", null ],
      [ "_sys_path", "namespacexdist_1_1plugin.html#a14ffeda533732441e0c6585789a2c131", null ],
      [ "is_xdist_master", "namespacexdist_1_1plugin.html#a6a437d82c4ab66aa99d9fe1218ef4251", null ]
    ] ],
    [ "remote", "namespacexdist_1_1remote.html", "namespacexdist_1_1remote" ],
    [ "report", "namespacexdist_1_1report.html", [
      [ "report_collection_diff", "namespacexdist_1_1report.html#a194b69f5ac7d286d4392c50fc42d07e4", null ]
    ] ],
    [ "scheduler", "namespacexdist_1_1scheduler.html", "namespacexdist_1_1scheduler" ],
    [ "workermanage", "namespacexdist_1_1workermanage.html", "namespacexdist_1_1workermanage" ]
];