var searchData=
[
  ['newhooks_2epy_0',['newhooks.py',['../newhooks_8py.html',1,'']]]
];
