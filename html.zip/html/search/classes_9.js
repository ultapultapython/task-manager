var searchData=
[
  ['scheduling_0',['Scheduling',['../classxdist_1_1scheduler_1_1protocol_1_1_scheduling.html',1,'xdist::scheduler::protocol']]],
  ['statrecorder_1',['StatRecorder',['../classxdist_1_1looponfail_1_1_stat_recorder.html',1,'xdist::looponfail']]]
];
