var searchData=
[
  ['version_5finfo_0',['version_info',['../classxdist_1_1remote_1_1_worker_info.html#a7cfa0a529f7f542e49c001d8bcb77344',1,'xdist::remote::WorkerInfo']]]
];
