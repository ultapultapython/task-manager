var searchData=
[
  ['producer_0',['Producer',['../classxdist_1_1remote_1_1_producer.html',1,'xdist::remote']]]
];
