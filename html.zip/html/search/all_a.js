var searchData=
[
  ['kwargs_0',['kwargs',['../classtest__remote_1_1_event_call.html#a0f70ebf80ba9993fa11be391c22cd3f6',1,'test_remote::EventCall']]]
];
