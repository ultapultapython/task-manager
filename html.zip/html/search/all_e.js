var searchData=
[
  ['option_0',['option',['../classacceptance__test_1_1_test_a_p_i.html#ae606b527563e366272126ba0511772d5',1,'acceptance_test::TestAPI']]],
  ['option_5fdict_1',['option_dict',['../namespacexdist_1_1remote.html#a10498acecf805d2a791ba23e737480ed',1,'xdist::remote']]]
];
