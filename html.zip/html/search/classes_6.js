var searchData=
[
  ['nodemanager_0',['NodeManager',['../classxdist_1_1workermanage_1_1_node_manager.html',1,'xdist::workermanage']]],
  ['nodepending_1',['NodePending',['../classxdist_1_1scheduler_1_1worksteal_1_1_node_pending.html',1,'xdist::scheduler::worksteal']]]
];
