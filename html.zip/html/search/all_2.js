var searchData=
[
  ['baseofmockgateway_0',['BaseOfMockGateway',['../namespacetest__dsession.html#a575b7b7a0637f3f063711401462c060f',1,'test_dsession']]],
  ['baseofmocknode_1',['BaseOfMockNode',['../namespacetest__dsession.html#a8251c97fb2b88c9d0d727c929f9e1007',1,'test_dsession']]]
];
