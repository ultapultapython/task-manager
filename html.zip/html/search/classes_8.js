var searchData=
[
  ['remotecontrol_0',['RemoteControl',['../classxdist_1_1looponfail_1_1_remote_control.html',1,'xdist::looponfail']]],
  ['remotehook_1',['RemoteHook',['../classxdist_1_1workermanage_1_1_worker_controller_1_1_remote_hook.html',1,'xdist::workermanage::WorkerController']]]
];
