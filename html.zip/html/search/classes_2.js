var searchData=
[
  ['hostrsync_0',['HostRSync',['../classxdist_1_1workermanage_1_1_host_r_sync.html',1,'xdist::workermanage']]]
];
