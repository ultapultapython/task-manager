var searchData=
[
  ['init_5fworker_5fsession_0',['init_worker_session',['../namespacexdist_1_1looponfail.html#a5ca081f103f670339c66335a696a4497',1,'xdist::looponfail']]],
  ['initgateway_1',['initgateway',['../classxdist_1_1looponfail_1_1_remote_control.html#a5eb3a6b9ae4c9b3b71d51035b7864786',1,'xdist::looponfail::RemoteControl']]],
  ['is_5fxdist_5fcontroller_2',['is_xdist_controller',['../namespacexdist_1_1plugin.html#acd2fde89c194d45f3c61ad72462961ea',1,'xdist::plugin']]],
  ['is_5fxdist_5fworker_3',['is_xdist_worker',['../namespacexdist_1_1plugin.html#a6c862597e099b16a4c3c2ba08fa5dd8a',1,'xdist::plugin']]]
];
