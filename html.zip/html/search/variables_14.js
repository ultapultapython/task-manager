var searchData=
[
  ['unserializerreport_0',['UnserializerReport',['../classtest__remote_1_1_test_worker_interactor.html#a11d03b7ede60947943976572f5f157ec',1,'test_remote::TestWorkerInteractor']]],
  ['use_5fcallback_1',['use_callback',['../classtest__remote_1_1_worker_setup.html#a0d5f7cacc912a1af69c7f4f353d4f5df',1,'test_remote::WorkerSetup']]]
];
