var classtest__newhooks_1_1_test_hooks =
[
    [ "create_test_file", "classtest__newhooks_1_1_test_hooks.html#aecce58540d683d2ee160013c3d232401", null ],
    [ "test_node_collection_finished", "classtest__newhooks_1_1_test_hooks.html#a639cf19e4c2633b89baada88cf285db3", null ],
    [ "test_runtest_logreport", "classtest__newhooks_1_1_test_hooks.html#a2c4f8188627cd712ff85a2ee5e06ccd8", null ]
];