var classtest__plugin_1_1_test_dist_options =
[
    [ "test_getrsyncdirs", "classtest__plugin_1_1_test_dist_options.html#a4c83b6d4db7d8634e41e1cf7bca900a2", null ],
    [ "test_getrsyncdirs_with_conftest", "classtest__plugin_1_1_test_dist_options.html#a954a2226ce8b3274afbcdca2ceaf1cb9", null ],
    [ "test_getrsyncignore", "classtest__plugin_1_1_test_dist_options.html#ae53e0280a236339df92df1284a4c2b2c", null ],
    [ "test_getxspecs", "classtest__plugin_1_1_test_dist_options.html#aceba104de6951403d1ca7ffe3baccd0c", null ],
    [ "test_xspecs_multiplied", "classtest__plugin_1_1_test_dist_options.html#ae2dd2707a00583e566e2861b1c13c7d6", null ]
];