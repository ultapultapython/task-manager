var classtest__remote_1_1_event_call =
[
    [ "__init__", "classtest__remote_1_1_event_call.html#a6253d55d552a21935e92cd5fcbaf941c", null ],
    [ "__str__", "classtest__remote_1_1_event_call.html#a8b7d071654932af15a7044bdeb932aff", null ],
    [ "kwargs", "classtest__remote_1_1_event_call.html#a0f70ebf80ba9993fa11be391c22cd3f6", null ],
    [ "name", "classtest__remote_1_1_event_call.html#aed4fc039c4c299e97f75d6d18a7a3757", null ]
];