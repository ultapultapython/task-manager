var classacceptance__test_1_1_test_dist_each =
[
    [ "test_simple", "classacceptance__test_1_1_test_dist_each.html#afb81b2188348ea6b0d42e2b23fd8349f", null ],
    [ "test_simple_diffoutput", "classacceptance__test_1_1_test_dist_each.html#aeb3fb3f4f124f32aad68adb8c60a1b9e", null ]
];