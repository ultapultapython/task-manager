var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", "dir_49e56c817e5e54854c35e136979f97ca" ],
    [ "example", "dir_cfafba98a580ce4b62f8a6fa96d7cbb0.html", "dir_cfafba98a580ce4b62f8a6fa96d7cbb0" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "testing", "dir_64f94c193e4d03baf6e89b1053934749.html", "dir_64f94c193e4d03baf6e89b1053934749" ]
];