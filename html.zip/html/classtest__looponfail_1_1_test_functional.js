var classtest__looponfail_1_1_test_functional =
[
    [ "test_fail_to_ok", "classtest__looponfail_1_1_test_functional.html#aee08b098ffd975733f55d7f833d1927d", null ],
    [ "test_xfail_passes", "classtest__looponfail_1_1_test_functional.html#acc84a3b01a7209141a1d0e2f979690b2", null ]
];