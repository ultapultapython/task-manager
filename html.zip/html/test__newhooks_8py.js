var test__newhooks_8py =
[
    [ "test_newhooks.TestHooks", "classtest__newhooks_1_1_test_hooks.html", "classtest__newhooks_1_1_test_hooks" ],
    [ "test_newhooks.TestCrashItem", "classtest__newhooks_1_1_test_crash_item.html", "classtest__newhooks_1_1_test_crash_item" ]
];