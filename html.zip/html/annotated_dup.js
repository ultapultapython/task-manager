var annotated_dup =
[
    [ "acceptance_test", "namespaceacceptance__test.html", [
      [ "TestAPI", "classacceptance__test_1_1_test_a_p_i.html", "classacceptance__test_1_1_test_a_p_i" ],
      [ "TestDistEach", "classacceptance__test_1_1_test_dist_each.html", "classacceptance__test_1_1_test_dist_each" ],
      [ "TestDistribution", "classacceptance__test_1_1_test_distribution.html", "classacceptance__test_1_1_test_distribution" ],
      [ "TestFileScope", "classacceptance__test_1_1_test_file_scope.html", "classacceptance__test_1_1_test_file_scope" ],
      [ "TestGroupScope", "classacceptance__test_1_1_test_group_scope.html", "classacceptance__test_1_1_test_group_scope" ],
      [ "TestLoadScope", "classacceptance__test_1_1_test_load_scope.html", "classacceptance__test_1_1_test_load_scope" ],
      [ "TestLocking", "classacceptance__test_1_1_test_locking.html", "classacceptance__test_1_1_test_locking" ],
      [ "TestNodeFailure", "classacceptance__test_1_1_test_node_failure.html", "classacceptance__test_1_1_test_node_failure" ],
      [ "TestTerminalReporting", "classacceptance__test_1_1_test_terminal_reporting.html", "classacceptance__test_1_1_test_terminal_reporting" ],
      [ "TestWarnings", "classacceptance__test_1_1_test_warnings.html", "classacceptance__test_1_1_test_warnings" ]
    ] ],
    [ "test_delta", "namespacetest__delta.html", [
      [ "Delta1", "classtest__delta_1_1_delta1.html", "classtest__delta_1_1_delta1" ],
      [ "Delta2", "classtest__delta_1_1_delta2.html", "classtest__delta_1_1_delta2" ]
    ] ],
    [ "test_dsession", "namespacetest__dsession.html", [
      [ "MockGateway", "classtest__dsession_1_1_mock_gateway.html", "classtest__dsession_1_1_mock_gateway" ],
      [ "MockNode", "classtest__dsession_1_1_mock_node.html", "classtest__dsession_1_1_mock_node" ],
      [ "TestDistReporter", "classtest__dsession_1_1_test_dist_reporter.html", "classtest__dsession_1_1_test_dist_reporter" ],
      [ "TestEachScheduling", "classtest__dsession_1_1_test_each_scheduling.html", "classtest__dsession_1_1_test_each_scheduling" ],
      [ "TestLoadScheduling", "classtest__dsession_1_1_test_load_scheduling.html", "classtest__dsession_1_1_test_load_scheduling" ],
      [ "TestWorkStealingScheduling", "classtest__dsession_1_1_test_work_stealing_scheduling.html", "classtest__dsession_1_1_test_work_stealing_scheduling" ]
    ] ],
    [ "test_looponfail", "namespacetest__looponfail.html", [
      [ "TestFunctional", "classtest__looponfail_1_1_test_functional.html", "classtest__looponfail_1_1_test_functional" ],
      [ "TestLooponFailing", "classtest__looponfail_1_1_test_loopon_failing.html", "classtest__looponfail_1_1_test_loopon_failing" ],
      [ "TestRemoteControl", "classtest__looponfail_1_1_test_remote_control.html", "classtest__looponfail_1_1_test_remote_control" ],
      [ "TestStatRecorder", "classtest__looponfail_1_1_test_stat_recorder.html", "classtest__looponfail_1_1_test_stat_recorder" ]
    ] ],
    [ "test_newhooks", "namespacetest__newhooks.html", [
      [ "TestCrashItem", "classtest__newhooks_1_1_test_crash_item.html", "classtest__newhooks_1_1_test_crash_item" ],
      [ "TestHooks", "classtest__newhooks_1_1_test_hooks.html", "classtest__newhooks_1_1_test_hooks" ]
    ] ],
    [ "test_plugin", "namespacetest__plugin.html", [
      [ "TestDistOptions", "classtest__plugin_1_1_test_dist_options.html", "classtest__plugin_1_1_test_dist_options" ]
    ] ],
    [ "test_remote", "namespacetest__remote.html", [
      [ "EventCall", "classtest__remote_1_1_event_call.html", "classtest__remote_1_1_event_call" ],
      [ "TestWorkerInteractor", "classtest__remote_1_1_test_worker_interactor.html", "classtest__remote_1_1_test_worker_interactor" ],
      [ "WorkerSetup", "classtest__remote_1_1_worker_setup.html", "classtest__remote_1_1_worker_setup" ]
    ] ],
    [ "test_workermanage", "namespacetest__workermanage.html", [
      [ "MyWarning", "classtest__workermanage_1_1_my_warning.html", null ],
      [ "MyWarningUnknown", "classtest__workermanage_1_1_my_warning_unknown.html", null ],
      [ "TestHRSync", "classtest__workermanage_1_1_test_h_r_sync.html", "classtest__workermanage_1_1_test_h_r_sync" ],
      [ "TestNodeManager", "classtest__workermanage_1_1_test_node_manager.html", "classtest__workermanage_1_1_test_node_manager" ],
      [ "TestNodeManagerPopen", "classtest__workermanage_1_1_test_node_manager_popen.html", "classtest__workermanage_1_1_test_node_manager_popen" ]
    ] ],
    [ "util", "namespaceutil.html", [
      [ "MyWarning2", "classutil_1_1_my_warning2.html", null ]
    ] ],
    [ "xdist", "namespacexdist.html", [
      [ "dsession", "namespacexdist_1_1dsession.html", [
        [ "DSession", "classxdist_1_1dsession_1_1_d_session.html", "classxdist_1_1dsession_1_1_d_session" ],
        [ "Interrupted", "classxdist_1_1dsession_1_1_interrupted.html", null ],
        [ "TerminalDistReporter", "classxdist_1_1dsession_1_1_terminal_dist_reporter.html", "classxdist_1_1dsession_1_1_terminal_dist_reporter" ],
        [ "WorkerStatus", "classxdist_1_1dsession_1_1_worker_status.html", null ]
      ] ],
      [ "looponfail", "namespacexdist_1_1looponfail.html", [
        [ "RemoteControl", "classxdist_1_1looponfail_1_1_remote_control.html", "classxdist_1_1looponfail_1_1_remote_control" ],
        [ "StatRecorder", "classxdist_1_1looponfail_1_1_stat_recorder.html", "classxdist_1_1looponfail_1_1_stat_recorder" ],
        [ "WorkerFailSession", "classxdist_1_1looponfail_1_1_worker_fail_session.html", "classxdist_1_1looponfail_1_1_worker_fail_session" ]
      ] ],
      [ "remote", "namespacexdist_1_1remote.html", [
        [ "Marker", "classxdist_1_1remote_1_1_marker.html", null ],
        [ "Producer", "classxdist_1_1remote_1_1_producer.html", "classxdist_1_1remote_1_1_producer" ],
        [ "TestQueue", "classxdist_1_1remote_1_1_test_queue.html", "classxdist_1_1remote_1_1_test_queue" ],
        [ "WorkerInfo", "classxdist_1_1remote_1_1_worker_info.html", null ],
        [ "WorkerInteractor", "classxdist_1_1remote_1_1_worker_interactor.html", "classxdist_1_1remote_1_1_worker_interactor" ]
      ] ],
      [ "scheduler", "namespacexdist_1_1scheduler.html", [
        [ "each", "namespacexdist_1_1scheduler_1_1each.html", [
          [ "EachScheduling", "classxdist_1_1scheduler_1_1each_1_1_each_scheduling.html", "classxdist_1_1scheduler_1_1each_1_1_each_scheduling" ]
        ] ],
        [ "load", "namespacexdist_1_1scheduler_1_1load.html", [
          [ "LoadScheduling", "classxdist_1_1scheduler_1_1load_1_1_load_scheduling.html", "classxdist_1_1scheduler_1_1load_1_1_load_scheduling" ]
        ] ],
        [ "loadfile", "namespacexdist_1_1scheduler_1_1loadfile.html", [
          [ "LoadFileScheduling", "classxdist_1_1scheduler_1_1loadfile_1_1_load_file_scheduling.html", "classxdist_1_1scheduler_1_1loadfile_1_1_load_file_scheduling" ]
        ] ],
        [ "loadgroup", "namespacexdist_1_1scheduler_1_1loadgroup.html", [
          [ "LoadGroupScheduling", "classxdist_1_1scheduler_1_1loadgroup_1_1_load_group_scheduling.html", "classxdist_1_1scheduler_1_1loadgroup_1_1_load_group_scheduling" ]
        ] ],
        [ "loadscope", "namespacexdist_1_1scheduler_1_1loadscope.html", [
          [ "LoadScopeScheduling", "classxdist_1_1scheduler_1_1loadscope_1_1_load_scope_scheduling.html", "classxdist_1_1scheduler_1_1loadscope_1_1_load_scope_scheduling" ]
        ] ],
        [ "protocol", "namespacexdist_1_1scheduler_1_1protocol.html", [
          [ "Scheduling", "classxdist_1_1scheduler_1_1protocol_1_1_scheduling.html", "classxdist_1_1scheduler_1_1protocol_1_1_scheduling" ]
        ] ],
        [ "worksteal", "namespacexdist_1_1scheduler_1_1worksteal.html", [
          [ "NodePending", "classxdist_1_1scheduler_1_1worksteal_1_1_node_pending.html", null ],
          [ "WorkStealingScheduling", "classxdist_1_1scheduler_1_1worksteal_1_1_work_stealing_scheduling.html", "classxdist_1_1scheduler_1_1worksteal_1_1_work_stealing_scheduling" ]
        ] ]
      ] ],
      [ "workermanage", "namespacexdist_1_1workermanage.html", [
        [ "HostRSync", "classxdist_1_1workermanage_1_1_host_r_sync.html", "classxdist_1_1workermanage_1_1_host_r_sync" ],
        [ "Marker", "classxdist_1_1workermanage_1_1_marker.html", null ],
        [ "NodeManager", "classxdist_1_1workermanage_1_1_node_manager.html", "classxdist_1_1workermanage_1_1_node_manager" ],
        [ "WorkerController", "classxdist_1_1workermanage_1_1_worker_controller.html", "classxdist_1_1workermanage_1_1_worker_controller" ]
      ] ]
    ] ]
];