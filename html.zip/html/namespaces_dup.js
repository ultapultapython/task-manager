var namespaces_dup =
[
    [ "acceptance_test", "namespaceacceptance__test.html", "namespaceacceptance__test" ],
    [ "conf", "namespaceconf.html", [
      [ "author", "namespaceconf.html#a0b68e66074bc74dbb7460951f810b4c8", null ],
      [ "copyright", "namespaceconf.html#aa11e0a8e9c47ccc775796bd64c295d2c", null ],
      [ "exclude_patterns", "namespaceconf.html#a7ad48fb6f3e9b129c02346ea0d3527c1", null ],
      [ "extensions", "namespaceconf.html#ae475e080536acb271a0a0efe56c3ba42", null ],
      [ "html_theme", "namespaceconf.html#a012ba9863b958ed7baa933116f2a05b6", null ],
      [ "master_doc", "namespaceconf.html#aa95c63cf0a3d87fed36d450840c6fd48", null ],
      [ "project", "namespaceconf.html#a2803387c30920e3e74f46eb541db430d", null ],
      [ "templates_path", "namespaceconf.html#ae850ae634911b713e036b43894fdd525", null ]
    ] ],
    [ "conftest", "namespaceconftest.html", [
      [ "_divert_atexit", "namespaceconftest.html#a39a4230ff69c8f0967737ef926657d9e", null ],
      [ "getgspecs", "namespaceconftest.html#a967d27b9df7774933d162914fec835fb", null ],
      [ "getsocketspec", "namespaceconftest.html#ad720a33616a8652420adcc32816900f3", null ],
      [ "getspecssh", "namespaceconftest.html#af46855dcdd030934566ded1cc1ca3715", null ],
      [ "pytest_addoption", "namespaceconftest.html#abb622ae5b08b5ff5b9ee707fb2997634", null ],
      [ "specssh", "namespaceconftest.html#a8a0ebd743ec696afae8de9df3796d095", null ],
      [ "pytest_plugins", "namespaceconftest.html#ade4ed68f8579dae084ac5c0be90c7a2c", null ]
    ] ],
    [ "epsilon", "namespaceepsilon.html", [
      [ "epsilon1", "namespaceepsilon.html#a217d264e979c91af44d5d168f0213a84", null ],
      [ "epsilon2", "namespaceepsilon.html#a1f137e39840d06ca2507f3ee4ba7797a", null ],
      [ "epsilon3", "namespaceepsilon.html#a4a51662ea125bad1a6d2c5c7f4334103", null ]
    ] ],
    [ "test_alpha", "namespacetest__alpha.html", [
      [ "test_alpha0", "namespacetest__alpha.html#ac496116b6d2ffd43ca7c2bf76cc08400", null ],
      [ "test_alpha1", "namespacetest__alpha.html#aaaca1440fc57b9d5f2941e6313cc4b2b", null ],
      [ "test_alpha2", "namespacetest__alpha.html#abfb6d6e3e72ee7a4f6cbdccf0ba3b943", null ],
      [ "test_alpha3", "namespacetest__alpha.html#adc15a69a5e805e5455ce817cf0584393", null ],
      [ "test_alpha4", "namespacetest__alpha.html#a45759608fc4687d84e1fe6a95be52373", null ],
      [ "test_alpha5", "namespacetest__alpha.html#ab5cb65f9432f0d1096f05eb960f2215c", null ],
      [ "test_alpha6", "namespacetest__alpha.html#a4b68b5eb8ce452e25ff087d55ebae7e1", null ],
      [ "test_alpha7", "namespacetest__alpha.html#a5f2c76db29c84836159af4e783f9b765", null ],
      [ "test_alpha8", "namespacetest__alpha.html#a9b8f7bc2802ad9ada6f3d2634656bdc0", null ],
      [ "test_alpha9", "namespacetest__alpha.html#ab20a4e1128f7a186fef9e15bf950f93a", null ]
    ] ],
    [ "test_beta", "namespacetest__beta.html", [
      [ "test_beta0", "namespacetest__beta.html#abf1b9d6601a88882ba15a3ed901c8621", null ],
      [ "test_beta1", "namespacetest__beta.html#aacd4be5cf451f123dba93bf3e5ce9dc4", null ],
      [ "test_beta2", "namespacetest__beta.html#ade221f5f03583a879f1df5ad7a0a4f36", null ],
      [ "test_beta3", "namespacetest__beta.html#a6d1463597cf477649be90f93842c7291", null ],
      [ "test_beta4", "namespacetest__beta.html#a4069a42b8f1412728b6638b52e1a1be9", null ],
      [ "test_beta5", "namespacetest__beta.html#a07351022929b262718c0c66e39c1994b", null ],
      [ "test_beta6", "namespacetest__beta.html#ad2ef48b42801b8619cba0fd79b99e9f2", null ],
      [ "test_beta7", "namespacetest__beta.html#a1604ec7c444654bfe2c780c1ad185b5f", null ],
      [ "test_beta8", "namespacetest__beta.html#ad22f10edce892363bb2642c67557a9c3", null ],
      [ "test_beta9", "namespacetest__beta.html#a2c4863ce3f2d482d57e1128376d9b17d", null ]
    ] ],
    [ "test_delta", "namespacetest__delta.html", "namespacetest__delta" ],
    [ "test_dsession", "namespacetest__dsession.html", "namespacetest__dsession" ],
    [ "test_gamma", "namespacetest__gamma.html", [
      [ "test_gamma0", "namespacetest__gamma.html#aa10d0338e2f7d0ca6db0d12db5a29060", null ],
      [ "test_gamma1", "namespacetest__gamma.html#a011c998235b6146ebd9cd4f8154efde9", null ],
      [ "test_gamma2", "namespacetest__gamma.html#aee04f12ab6645daeb32378aeb4ae72ab", null ],
      [ "test_gamma3", "namespacetest__gamma.html#afec1bf7ca4ec0bee9f8e7918457e2645", null ],
      [ "test_gamma4", "namespacetest__gamma.html#adbf986fb78fedd8ab4381049c47d299d", null ],
      [ "test_gamma5", "namespacetest__gamma.html#ace825c035dea19704a808e065e4b3b40", null ],
      [ "test_gamma6", "namespacetest__gamma.html#a237bc703a45813f662be0c27b66c8b08", null ],
      [ "test_gamma7", "namespacetest__gamma.html#ac0ce2b7559ec3543161e25ad7c8f27bc", null ],
      [ "test_gamma8", "namespacetest__gamma.html#a6d256e2a550afafdd56800a4180a3461", null ],
      [ "test_gamma9", "namespacetest__gamma.html#a1eb6590fb20af8b92a25c62e964a7b8b", null ]
    ] ],
    [ "test_looponfail", "namespacetest__looponfail.html", "namespacetest__looponfail" ],
    [ "test_newhooks", "namespacetest__newhooks.html", "namespacetest__newhooks" ],
    [ "test_plugin", "namespacetest__plugin.html", "namespacetest__plugin" ],
    [ "test_remote", "namespacetest__remote.html", "namespacetest__remote" ],
    [ "test_workermanage", "namespacetest__workermanage.html", "namespacetest__workermanage" ],
    [ "util", "namespaceutil.html", "namespaceutil" ],
    [ "xdist", "namespacexdist.html", "namespacexdist" ]
];